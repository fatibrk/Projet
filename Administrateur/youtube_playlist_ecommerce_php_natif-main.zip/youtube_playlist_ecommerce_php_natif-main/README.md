# Ecommerce mini app youtube_playlist_ecommerce_php_natif

Video for my playlist todolist in my youtube channel : https://www.youtube.com/playlist?list=PLm_sigBWSRY2njwf_NS_GKtP0QvYDs6st

# Screenshots (FRONT OFFICE): 
## Page catégorie/produits
![image](https://user-images.githubusercontent.com/18069380/206854144-85afbc37-52e5-485b-b9f0-ba9e0b3af337.png)

## Product details
![image](https://user-images.githubusercontent.com/18069380/206854170-8fd92dd6-8cd9-45d2-9c85-7fe070799d9b.png)

## Add to cart / update / delete
![image](https://user-images.githubusercontent.com/18069380/206855292-a3854d96-8647-4892-a6a1-47af4d633121.png)


## Empty cart
![image](https://user-images.githubusercontent.com/18069380/206855253-a3aaf9d1-d93a-43c9-81c1-2c3a70416f4e.png)

## Cart page
![image](https://user-images.githubusercontent.com/18069380/206855349-ad78ac95-9da5-47b2-a824-b0d6f63dce85.png)

## Thank you page
![image](https://user-images.githubusercontent.com/18069380/206855204-6256614b-e0c8-47dc-a03d-f2269b28bb50.png)


# Screenshots (BACK OFFICE): 
## Add user / register
![image](https://user-images.githubusercontent.com/18069380/206855380-93d0556c-fccc-4b7a-a536-6372ccadda82.png)

## Categories (list) We can update/create/delete
![image](https://user-images.githubusercontent.com/18069380/206855389-a1ab503f-5015-49bb-aa04-cf40dfbde8da.png)

## products (list) We can update/create/delete
![image](https://user-images.githubusercontent.com/18069380/206855418-2a7c2a3b-84bf-4740-8662-3ba6083333f0.png)
![image](https://user-images.githubusercontent.com/18069380/206855426-a2e01360-9f87-49fb-9c04-2a0f5510d5e9.png)

## Orders
![image](https://user-images.githubusercontent.com/18069380/206855436-92983c9b-f39a-4ff5-adfb-554709f43bed.png)

## Order details
![image](https://user-images.githubusercontent.com/18069380/206855459-faa5c0ac-36db-4230-a336-7b430a42cd9e.png)


